package com.helpme.interviewdost

import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.IBinder

class AudioCaptureService : Service() {
    private var audioRecord: AudioRecord? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAudioCapture()
        return START_STICKY
    }

    private fun startAudioCapture() {
        val sampleRate = 44100
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize
        )

        audioRecord?.startRecording()

        // Start speech recognition
        startSpeechRecognition()
    }

    private fun startSpeechRecognition() {
        SpeechToTextService.startListening(this) { text ->
            GeminiClient.getResponse(text) { response ->
                OverlayService.updateText(response)
            }
        }
    }

    override fun onDestroy() {
        audioRecord?.stop()
        audioRecord?.release()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}
