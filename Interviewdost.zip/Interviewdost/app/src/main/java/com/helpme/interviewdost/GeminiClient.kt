package com.helpme.interviewdost

import okhttp3.*
import org.json.JSONObject
import java.io.IOException

object GeminiClient {
    private const val API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateText"
    private const val API_KEY = "YOUR_GEMINI_API_KEY"

    fun getResponse(query: String, callback: (String) -> Unit) {
        val client = OkHttpClient()
        val requestBody = RequestBody.create(
            MediaType.parse("application/json"),
            JSONObject().put("prompt", query)
                .put("temperature", 0.7)
                .put("maxOutputTokens", 100)
                .toString()
        )

        val request = Request.Builder()
            .url("$API_URL?key=$API_KEY")
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback("Error: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body()?.string()
                val reply = JSONObject(body ?: "{}").optJSONArray("candidates")?.optJSONObject(0)?.optString("output")
                callback(reply ?: "No response")
            }
        })
    }
}
